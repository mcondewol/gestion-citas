# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.32)
# Database: bookmedik
# Generation Time: 2021-10-05 21:46:20 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table catalogo_medicos
# ------------------------------------------------------------

DROP TABLE IF EXISTS `catalogo_medicos`;

CREATE TABLE `catalogo_medicos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `idservicio` int(11) NOT NULL,
  `usering` int(11) NOT NULL,
  `fechaing` datetime NOT NULL,
  `usermod` int(11) DEFAULT NULL,
  `fechamod` datetime DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_medico_idx` (`usering`),
  KEY `user_mod_medico_idx` (`usermod`),
  KEY `servicio_medico_idx` (`idservicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `catalogo_medicos` WRITE;
/*!40000 ALTER TABLE `catalogo_medicos` DISABLE KEYS */;

INSERT INTO `catalogo_medicos` (`id`, `nombre`, `idservicio`, `usering`, `fechaing`, `usermod`, `fechamod`, `estado`)
VALUES
	(3,'Juan Martinez',4,130,'2021-09-02 18:04:11',130,'2021-09-09 17:08:47',1),
	(4,'Ruben Salazar',2,130,'2021-09-02 18:09:49',130,'2021-09-16 16:48:26',1),
	(6,'Rodrigo Gutierrez',1,130,'2021-09-09 15:26:49',130,'2021-09-09 17:09:39',1),
	(9,'JOSE DE LEON LOPEZ',1,130,'2021-09-09 17:13:18',130,'2021-09-09 17:13:38',0),
	(10,'Jorge Quiñonez',3,130,'2021-09-09 17:20:11',130,'2021-09-09 17:20:27',1),
	(11,'JOSE MARTINEZ',2,130,'2021-09-09 18:23:51',130,'2021-09-09 18:24:09',0);

/*!40000 ALTER TABLE `catalogo_medicos` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table catalogo_servicios
# ------------------------------------------------------------

DROP TABLE IF EXISTS `catalogo_servicios`;

CREATE TABLE `catalogo_servicios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `idubicacion` int(11) NOT NULL,
  `usering` int(11) NOT NULL,
  `fechaing` datetime NOT NULL,
  `usermod` int(11) DEFAULT NULL,
  `fechamod` datetime DEFAULT NULL,
  `tipo` varchar(45) NOT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_servicio_idx` (`usering`),
  KEY `user_mod_servicio_idx` (`usermod`),
  KEY `ubicacion_servicio_idx` (`idubicacion`),
  CONSTRAINT `ubicacion_servicio` FOREIGN KEY (`idubicacion`) REFERENCES `catalogo_ubicaciones` (`id`),
  CONSTRAINT `user_mod_servicio` FOREIGN KEY (`usermod`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `user_servicio` FOREIGN KEY (`usering`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `catalogo_servicios` WRITE;
/*!40000 ALTER TABLE `catalogo_servicios` DISABLE KEYS */;

INSERT INTO `catalogo_servicios` (`id`, `nombre`, `idubicacion`, `usering`, `fechaing`, `usermod`, `fechamod`, `tipo`, `estado`)
VALUES
	(1,'Médicina Interna',1,135,'2021-08-09 00:00:00',NULL,'2021-08-09 00:00:00','S',1),
	(2,'Pediatriaa',1,135,'2021-08-09 00:00:00',NULL,'2021-09-16 16:55:12','S',1),
	(3,'Traumatología y Ortopedia',2,135,'2021-08-09 00:00:00',NULL,'2021-09-16 16:09:57','S',1),
	(4,'Cirugía General',2,135,'2021-08-09 00:00:00',NULL,'2021-09-16 16:53:35','S',1),
	(5,'Dermatología',1,135,'2021-08-09 00:00:00',NULL,'2021-08-09 00:00:00','S',1),
	(6,'Oftalmología',1,130,'2021-09-16 15:45:48',130,'2021-09-16 15:45:48','S',1);

/*!40000 ALTER TABLE `catalogo_servicios` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table category
# ------------------------------------------------------------

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `idlocation` int(11) DEFAULT NULL,
  `usering` int(11) DEFAULT NULL,
  `fechaing` datetime DEFAULT NULL,
  `usermod` int(11) DEFAULT NULL,
  `fechamod` datetime DEFAULT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `estado` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;

INSERT INTO `category` (`id`, `name`, `idlocation`, `usering`, `fechaing`, `usermod`, `fechamod`, `tipo`, `estado`)
VALUES
	(1,'Modulo 1',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(5,'test1',11,NULL,NULL,NULL,NULL,NULL,NULL),
	(6,'test2',1244,1,'2021-09-22 21:55:31',NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table departamentos
# ------------------------------------------------------------

DROP TABLE IF EXISTS `departamentos`;

CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `fechamod` datetime DEFAULT NULL,
  `usermod` int(11) DEFAULT NULL,
  `fechaing` datetime DEFAULT NULL,
  `usering` int(11) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `departamentos` WRITE;
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;

INSERT INTO `departamentos` (`id`, `nombre`, `fechamod`, `usermod`, `fechaing`, `usering`, `estado`)
VALUES
	(1,'Guatemala',NULL,1,NULL,1,1),
	(2,'El Progreso',NULL,1,NULL,1,1),
	(3,'Sacatepéquez',NULL,1,NULL,1,1),
	(4,'Chimaltenango',NULL,1,NULL,1,1),
	(5,'Escuintla',NULL,1,NULL,1,1),
	(6,'Santa Rosa',NULL,1,NULL,1,1),
	(7,'Sololá',NULL,1,NULL,1,1),
	(8,'Totonicapán',NULL,1,NULL,1,1),
	(9,'Quetzaltenango',NULL,1,NULL,1,1),
	(10,'Suchitepéquez',NULL,1,NULL,1,1),
	(11,'Retalhuleu',NULL,1,NULL,1,1),
	(12,'San Marcos',NULL,1,NULL,1,1),
	(13,'Huehuetenango',NULL,1,NULL,1,1),
	(14,'Quiché',NULL,1,NULL,1,1),
	(15,'Baja Verapaz',NULL,1,NULL,1,1),
	(16,'Alta Verapaz',NULL,1,NULL,1,1),
	(17,'Petén',NULL,1,NULL,1,1),
	(18,'Izabal',NULL,1,NULL,1,1),
	(19,'Zacapa',NULL,1,NULL,1,1),
	(20,'Chiquimula',NULL,1,NULL,1,1),
	(21,'Jalapa',NULL,1,NULL,1,1),
	(22,'Jutiapa',NULL,1,NULL,1,1);

/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table location
# ------------------------------------------------------------

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `id_municipio` int(11) DEFAULT NULL,
  `usering` int(11) DEFAULT NULL,
  `fechaing` datetime DEFAULT NULL,
  `usermod` int(11) DEFAULT NULL,
  `estado` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;

INSERT INTO `location` (`id`, `name`, `id_municipio`, `usering`, `fechaing`, `usermod`, `estado`)
VALUES
	(1,'',120,1,'2021-09-24 21:26:51',NULL,NULL),
	(2,'test 2',14,1,'2021-09-24 21:28:29',NULL,NULL),
	(3,'test1',99,1,'2021-09-24 21:29:50',NULL,NULL);

/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table medic
# ------------------------------------------------------------

DROP TABLE IF EXISTS `medic`;

CREATE TABLE `medic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `day_of_birth` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `esemana` varchar(255) DEFAULT NULL,
  `time_hi_esemana` varchar(50) DEFAULT NULL,
  `time_hf_esemana` varchar(50) DEFAULT NULL,
  `fsemana` varchar(255) DEFAULT NULL,
  `time_hi_fsemana` varchar(50) DEFAULT NULL,
  `time_hf_fsemana` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `medic_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `medic` WRITE;
/*!40000 ALTER TABLE `medic` DISABLE KEYS */;

INSERT INTO `medic` (`id`, `no`, `name`, `lastname`, `gender`, `day_of_birth`, `email`, `address`, `phone`, `image`, `is_active`, `created_at`, `category_id`, `location_id`, `esemana`, `time_hi_esemana`, `time_hf_esemana`, `fsemana`, `time_hi_fsemana`, `time_hf_fsemana`)
VALUES
	(1,NULL,'Juan','Perez',NULL,NULL,'test@correo.com','nueva','43121232',NULL,1,'2021-09-21 21:12:27',1,2,NULL,NULL,NULL,NULL,NULL,NULL),
	(2,NULL,'Juan','Perz2',NULL,NULL,'nuevo@xo.com','calee','232132',NULL,1,'2021-09-28 18:56:26',1,3,NULL,NULL,NULL,NULL,NULL,NULL),
	(3,NULL,'No','sll',NULL,NULL,'nuevo@xo.com','122','43233131',NULL,1,'2021-10-04 20:49:46',1,2,NULL,NULL,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `medic` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table municipios
# ------------------------------------------------------------

DROP TABLE IF EXISTS `municipios`;

CREATE TABLE `municipios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `id_departamento` int(11) DEFAULT NULL,
  `fechamod` datetime DEFAULT NULL,
  `usermod` int(11) DEFAULT NULL,
  `fechaing` datetime DEFAULT NULL,
  `usering` int(11) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `municipios` WRITE;
/*!40000 ALTER TABLE `municipios` DISABLE KEYS */;

INSERT INTO `municipios` (`id`, `nombre`, `id_departamento`, `fechamod`, `usermod`, `fechaing`, `usering`, `estado`)
VALUES
	(1,'Guatemala',1,NULL,1,NULL,1,1),
	(2,'Santa Catarina Pinula',1,NULL,1,NULL,1,1),
	(3,'San José Pinula',1,NULL,1,NULL,1,1),
	(4,'San José del Golfo',1,NULL,1,NULL,1,1),
	(5,'Palencia',1,NULL,1,NULL,1,1),
	(6,'Chinautla',1,NULL,1,NULL,1,1),
	(7,'San Pedro Ayampuc',1,NULL,1,NULL,1,1),
	(8,'Mixco',1,NULL,1,NULL,1,1),
	(9,'San Pedro Sacatepéquez',1,NULL,1,NULL,1,1),
	(10,'San Juan Sacatepéquez',1,NULL,1,NULL,1,1),
	(11,'San Raymundo',1,NULL,1,NULL,1,1),
	(12,'Chuarrancho',1,NULL,1,NULL,1,1),
	(13,'Fraijanes',1,NULL,1,NULL,1,1),
	(14,'Amatitlán',1,NULL,1,NULL,1,1),
	(15,'Villa Nueva',1,NULL,1,NULL,1,1),
	(16,'Villa Canales',1,NULL,1,NULL,1,1),
	(17,'Petapa',1,NULL,1,NULL,1,1),
	(18,'Guastatoya',2,NULL,1,NULL,1,1),
	(19,'Morazán',2,NULL,1,NULL,1,1),
	(20,'San Agustín Acasaguastlán',2,NULL,1,NULL,1,1),
	(21,'San Cristóbal Acasaguastlán',2,NULL,1,NULL,1,1),
	(22,'El Jícaro',2,NULL,1,NULL,1,1),
	(23,'Sansare',2,NULL,1,NULL,1,1),
	(24,'Sanarate',2,NULL,1,NULL,1,1),
	(25,'San Antonio la Paz',2,NULL,1,NULL,1,1),
	(26,'Antigua Guatemala',3,NULL,1,NULL,1,1),
	(27,'Jocotenango',3,NULL,1,NULL,1,1),
	(28,'Pastores',3,NULL,1,NULL,1,1),
	(29,'Sumpango',3,NULL,1,NULL,1,1),
	(30,'Santo Domingo Xenacoj',3,NULL,1,NULL,1,1),
	(31,'Santiago Sacatepéquez',3,NULL,1,NULL,1,1),
	(32,'San Bartolomé Milpas Altas',3,NULL,1,NULL,1,1),
	(33,'San Lucas Sacatepéquez',3,NULL,1,NULL,1,1),
	(34,'Santa Lucía Milpas Altas',3,NULL,1,NULL,1,1),
	(35,'Magdalena Milpas Altas',3,NULL,1,NULL,1,1),
	(36,'Santa María de Jesús',3,NULL,1,NULL,1,1),
	(37,'Ciudad Vieja',3,NULL,1,NULL,1,1),
	(38,'San Miguel Dueñas',3,NULL,1,NULL,1,1),
	(39,'Alotenango',3,NULL,1,NULL,1,1),
	(40,'San Antonio Aguas Calientes',3,NULL,1,NULL,1,1),
	(41,'Santa Catarina Barahona',3,NULL,1,NULL,1,1),
	(42,'Chimaltenango',4,NULL,1,NULL,1,1),
	(43,'San José Poaquil',4,NULL,1,NULL,1,1),
	(44,'San Martín Jilotepeque',4,NULL,1,NULL,1,1),
	(45,'Comalapa',4,NULL,1,NULL,1,1),
	(46,'Santa Apolonia',4,NULL,1,NULL,1,1),
	(47,'Tecpán Guatemala',4,NULL,1,NULL,1,1),
	(48,'Patzún',4,NULL,1,NULL,1,1),
	(49,'Pochuta',4,NULL,1,NULL,1,1),
	(50,'Patzicía',4,NULL,1,NULL,1,1),
	(51,'Santa Cruz Balanyá',4,NULL,1,NULL,1,1),
	(52,'Acatenango',4,NULL,1,NULL,1,1),
	(53,'Yepocapa',4,NULL,1,NULL,1,1),
	(54,'San Andrés Itzapa',4,NULL,1,NULL,1,1),
	(55,'Parramos',4,NULL,1,NULL,1,1),
	(56,'Zaragoza',4,NULL,1,NULL,1,1),
	(57,'El Tejar',4,NULL,1,NULL,1,1),
	(58,'Escuintla',5,NULL,1,NULL,1,1),
	(59,'Santa Lucía Cotzumalguapa',5,NULL,1,NULL,1,1),
	(60,'La Democracia',5,NULL,1,NULL,1,1),
	(61,'Siquinalá',5,NULL,1,NULL,1,1),
	(62,'Masagua',5,NULL,1,NULL,1,1),
	(63,'Tiquisate',5,NULL,1,NULL,1,1),
	(64,'La Gomera',5,NULL,1,NULL,1,1),
	(65,'Guanagazapa',5,NULL,1,NULL,1,1),
	(66,'San José',5,NULL,1,NULL,1,1),
	(67,'Iztapa',5,NULL,1,NULL,1,1),
	(68,'Palín',5,NULL,1,NULL,1,1),
	(69,'San Vicente Pacaya',5,NULL,1,NULL,1,1),
	(70,'Nueva Concepción',5,NULL,1,NULL,1,1),
	(71,'Cuilapa',6,NULL,1,NULL,1,1),
	(72,'Barberena',6,NULL,1,NULL,1,1),
	(73,'Santa Rosa de Lima',6,NULL,1,NULL,1,1),
	(74,'Casillas',6,NULL,1,NULL,1,1),
	(75,'San Rafael las Flores',6,NULL,1,NULL,1,1),
	(76,'Oratorio',6,NULL,1,NULL,1,1),
	(77,'San Juan Tecuaco',6,NULL,1,NULL,1,1),
	(78,'Chiquimulilla',6,NULL,1,NULL,1,1),
	(79,'Taxisco',6,NULL,1,NULL,1,1),
	(80,'Santa María Ixhuatán',6,NULL,1,NULL,1,1),
	(81,'Guazacapán',6,NULL,1,NULL,1,1),
	(82,'Santa Cruz Naranjo',6,NULL,1,NULL,1,1),
	(83,'Pueblo Nuevo Viñas',6,NULL,1,NULL,1,1),
	(84,'Nueva Santa Rosa',6,NULL,1,NULL,1,1),
	(85,'Sololá',7,NULL,1,NULL,1,1),
	(86,'San José Chacayá',7,NULL,1,NULL,1,1),
	(87,'Santa María Visitación',7,NULL,1,NULL,1,1),
	(88,'Santa Lucía Utatlán',7,NULL,1,NULL,1,1),
	(89,'Nahualá',7,NULL,1,NULL,1,1),
	(90,'Santa Catarina Ixtahuacán',7,NULL,1,NULL,1,1),
	(91,'Santa Clara la Laguna',7,NULL,1,NULL,1,1),
	(92,'Concepción',7,NULL,1,NULL,1,1),
	(93,'San Andrés Semetabaj',7,NULL,1,NULL,1,1),
	(94,'Panajachel',7,NULL,1,NULL,1,1),
	(95,'Santa Catarina Palopó',7,NULL,1,NULL,1,1),
	(96,'San Antonio Palopó',7,NULL,1,NULL,1,1),
	(97,'San Lucas Tolimán',7,NULL,1,NULL,1,1),
	(98,'Santa Cruz la Laguna',7,NULL,1,NULL,1,1),
	(99,'San Pablo la Laguna',7,NULL,1,NULL,1,1),
	(100,'San Marcos la Laguna',7,NULL,1,NULL,1,1),
	(101,'San Juan la Laguna',7,NULL,1,NULL,1,1),
	(102,'San Pedro la Laguna',7,NULL,1,NULL,1,1),
	(103,'Santiago Atitlán',7,NULL,1,NULL,1,1),
	(104,'Totonicapán',8,NULL,1,NULL,1,1),
	(105,'San Cristóbal Totonicapán',8,NULL,1,NULL,1,1),
	(106,'San Francisco el Alto',8,NULL,1,NULL,1,1),
	(107,'San Andrés Xecul',8,NULL,1,NULL,1,1),
	(108,'Momostenango',8,NULL,1,NULL,1,1),
	(109,'Santa María Chiquimula',8,NULL,1,NULL,1,1),
	(110,'Santa Lucía la Reforma',8,NULL,1,NULL,1,1),
	(111,'San Bartolo',8,NULL,1,NULL,1,1),
	(112,'Quetzaltenango',9,NULL,1,NULL,1,1),
	(113,'Salcajá',9,NULL,1,NULL,1,1),
	(114,'Olintepeque',9,NULL,1,NULL,1,1),
	(115,'San Carlos Sija',9,NULL,1,NULL,1,1),
	(116,'Sibilia',9,NULL,1,NULL,1,1),
	(117,'Cabricán',9,NULL,1,NULL,1,1),
	(118,'Cajolá',9,NULL,1,NULL,1,1),
	(119,'San Miguel Siguilá',9,NULL,1,NULL,1,1),
	(120,'Ostuncalco',9,NULL,1,NULL,1,1),
	(121,'San Mateo',9,NULL,1,NULL,1,1),
	(122,'Concepción Chiquirichapa',9,NULL,1,NULL,1,1),
	(123,'San Martín Sacatepéquez',9,NULL,1,NULL,1,1),
	(124,'Almolonga',9,NULL,1,NULL,1,1),
	(125,'Cantel',9,NULL,1,NULL,1,1),
	(126,'Huitán',9,NULL,1,NULL,1,1),
	(127,'Zunil',9,NULL,1,NULL,1,1),
	(128,'Colomba',9,NULL,1,NULL,1,1),
	(129,'San Francisco la Unión',9,NULL,1,NULL,1,1),
	(130,'El Palmar',9,NULL,1,NULL,1,1),
	(131,'Coatepeque',9,NULL,1,NULL,1,1),
	(132,'Génova',9,NULL,1,NULL,1,1),
	(133,'Flores Costa Cuca',9,NULL,1,NULL,1,1),
	(134,'La Esperanza',9,NULL,1,NULL,1,1),
	(135,'Palestina de los Altos',9,NULL,1,NULL,1,1),
	(136,'Mazatenango',10,NULL,1,NULL,1,1),
	(137,'Cuyotenango',10,NULL,1,NULL,1,1),
	(138,'San Francisco Zapotitlán',10,NULL,1,NULL,1,1),
	(139,'San Bernardino',10,NULL,1,NULL,1,1),
	(140,'San José el Idolo',10,NULL,1,NULL,1,1),
	(141,'Santo Domingo Suchitepéquez',10,NULL,1,NULL,1,1),
	(142,'San Lorenzo',10,NULL,1,NULL,1,1),
	(143,'Samayac',10,NULL,1,NULL,1,1),
	(144,'San Pablo Jocopilas',10,NULL,1,NULL,1,1),
	(145,'San Antonio Suchitepéquez',10,NULL,1,NULL,1,1),
	(146,'San Miguel Panán',10,NULL,1,NULL,1,1),
	(147,'San Gabriel',10,NULL,1,NULL,1,1),
	(148,'Chicacao',10,NULL,1,NULL,1,1),
	(149,'Patulul',10,NULL,1,NULL,1,1),
	(150,'Santa Bárbara',10,NULL,1,NULL,1,1),
	(151,'San Juan Bautista',10,NULL,1,NULL,1,1),
	(152,'Santo Tomás la Unión',10,NULL,1,NULL,1,1),
	(153,'Zunilito',10,NULL,1,NULL,1,1),
	(154,'Pueblo Nuevo',10,NULL,1,NULL,1,1),
	(155,'Río Bravo',10,NULL,1,NULL,1,1),
	(156,'San José La Máquina',10,NULL,1,NULL,1,1),
	(157,'Retalhuleu',11,NULL,1,NULL,1,1),
	(158,'San Sebastián',11,NULL,1,NULL,1,1),
	(159,'Santa Cruz Muluá',11,NULL,1,NULL,1,1),
	(160,'San Martín Zapotitlán',11,NULL,1,NULL,1,1),
	(161,'San Felipe',11,NULL,1,NULL,1,1),
	(162,'San Andrés Villa Seca',11,NULL,1,NULL,1,1),
	(163,'Champerico',11,NULL,1,NULL,1,1),
	(164,'Nuevo San Carlos',11,NULL,1,NULL,1,1),
	(165,'El Asintal',11,NULL,1,NULL,1,1),
	(166,'San Marcos',12,NULL,1,NULL,1,1),
	(167,'San Pedro Sacatepéquez',12,NULL,1,NULL,1,1),
	(168,'San Antonio Sacatepéquez',12,NULL,1,NULL,1,1),
	(169,'Comitancillo',12,NULL,1,NULL,1,1),
	(170,'San Miguel Ixtahuacán',12,NULL,1,NULL,1,1),
	(171,'Concepción Tutuapa',12,NULL,1,NULL,1,1),
	(172,'Tacaná',12,NULL,1,NULL,1,1),
	(173,'Sibinal',12,NULL,1,NULL,1,1),
	(174,'Tajumulco',12,NULL,1,NULL,1,1),
	(175,'Tejutla',12,NULL,1,NULL,1,1),
	(176,'San Rafael Pié de la Cuesta',12,NULL,1,NULL,1,1),
	(177,'Nuevo Progreso',12,NULL,1,NULL,1,1),
	(178,'El Tumbador',12,NULL,1,NULL,1,1),
	(179,'El Rodeo',12,NULL,1,NULL,1,1),
	(180,'Malacatán',12,NULL,1,NULL,1,1),
	(181,'Catarina',12,NULL,1,NULL,1,1),
	(182,'Ayutla',12,NULL,1,NULL,1,1),
	(183,'Ocós',12,NULL,1,NULL,1,1),
	(184,'San Pablo',12,NULL,1,NULL,1,1),
	(185,'El Quetzal',12,NULL,1,NULL,1,1),
	(186,'La Reforma',12,NULL,1,NULL,1,1),
	(187,'Pajapita',12,NULL,1,NULL,1,1),
	(188,'Ixchiguán',12,NULL,1,NULL,1,1),
	(189,'San José Ojetenán',12,NULL,1,NULL,1,1),
	(190,'San Cristóbal Cucho',12,NULL,1,NULL,1,1),
	(191,'Sipacapa',12,NULL,1,NULL,1,1),
	(192,'Esquipulas Palo Gordo',12,NULL,1,NULL,1,1),
	(193,'Río Blanco',12,NULL,1,NULL,1,1),
	(194,'San Lorenzo',12,NULL,1,NULL,1,1),
	(195,'La Blanca',12,NULL,1,NULL,1,1),
	(196,'Huehuetenango',13,NULL,1,NULL,1,1),
	(197,'Chiantla',13,NULL,1,NULL,1,1),
	(198,'Malacatancito',13,NULL,1,NULL,1,1),
	(199,'Cuilco',13,NULL,1,NULL,1,1),
	(200,'Nentón',13,NULL,1,NULL,1,1),
	(201,'San Pedro Necta',13,NULL,1,NULL,1,1),
	(202,'Jacaltenango',13,NULL,1,NULL,1,1),
	(203,'Soloma',13,NULL,1,NULL,1,1),
	(204,'Ixtahuacán',13,NULL,1,NULL,1,1),
	(205,'Santa Bárbara',13,NULL,1,NULL,1,1),
	(206,'La Libertad',13,NULL,1,NULL,1,1),
	(207,'La Democracia',13,NULL,1,NULL,1,1),
	(208,'San Miguel Acatán',13,NULL,1,NULL,1,1),
	(209,'San Rafael la Independencia',13,NULL,1,NULL,1,1),
	(210,'Todos Santos Cuchumatán',13,NULL,1,NULL,1,1),
	(211,'San Juan Atitán',13,NULL,1,NULL,1,1),
	(212,'Santa Eulalia',13,NULL,1,NULL,1,1),
	(213,'San Mateo Ixtatán',13,NULL,1,NULL,1,1),
	(214,'Colotenango',13,NULL,1,NULL,1,1),
	(215,'San Sebastián Huehuetenango',13,NULL,1,NULL,1,1),
	(216,'Tectitán',13,NULL,1,NULL,1,1),
	(217,'Concepción Huista',13,NULL,1,NULL,1,1),
	(218,'San Juan Ixcoy',13,NULL,1,NULL,1,1),
	(219,'San Antonio Huista',13,NULL,1,NULL,1,1),
	(220,'San Sebastián Coatán',13,NULL,1,NULL,1,1),
	(221,'Barillas',13,NULL,1,NULL,1,1),
	(222,'Aguacatán',13,NULL,1,NULL,1,1),
	(223,'San Rafael Petzal',13,NULL,1,NULL,1,1),
	(224,'San Gaspar Ixchil',13,NULL,1,NULL,1,1),
	(225,'Santiago Chimaltenango',13,NULL,1,NULL,1,1),
	(226,'Santa Ana Huista',13,NULL,1,NULL,1,1),
	(227,'Unión Cantinil',13,NULL,1,NULL,1,1),
	(228,'Santa Cruz del Quiché',14,NULL,1,NULL,1,1),
	(229,'Chiché',14,NULL,1,NULL,1,1),
	(230,'Chinique',14,NULL,1,NULL,1,1),
	(231,'Zacualpa',14,NULL,1,NULL,1,1),
	(232,'Chajul',14,NULL,1,NULL,1,1),
	(233,'Chichicastenango',14,NULL,1,NULL,1,1),
	(234,'Patzité',14,NULL,1,NULL,1,1),
	(235,'San Antonio Ilotenango',14,NULL,1,NULL,1,1),
	(236,'San Pedro Jocopilas',14,NULL,1,NULL,1,1),
	(237,'Cunén',14,NULL,1,NULL,1,1),
	(238,'San Juan Cotzal',14,NULL,1,NULL,1,1),
	(239,'Joyabaj',14,NULL,1,NULL,1,1),
	(240,'Nebaj',14,NULL,1,NULL,1,1),
	(241,'San Andrés Sajcabajá',14,NULL,1,NULL,1,1),
	(242,'Uspantán',14,NULL,1,NULL,1,1),
	(243,'Sacapulas',14,NULL,1,NULL,1,1),
	(244,'San Bartolomé Jocotenango',14,NULL,1,NULL,1,1),
	(245,'Canillá',14,NULL,1,NULL,1,1),
	(246,'Chicamán',14,NULL,1,NULL,1,1),
	(247,'Ixcán',14,NULL,1,NULL,1,1),
	(248,'Pachalum',14,NULL,1,NULL,1,1),
	(249,'Salamá',15,NULL,1,NULL,1,1),
	(250,'San Miguel Chicaj',15,NULL,1,NULL,1,1),
	(251,'Rabinal',15,NULL,1,NULL,1,1),
	(252,'Cubulco',15,NULL,1,NULL,1,1),
	(253,'Granados',15,NULL,1,NULL,1,1),
	(254,'El Chol',15,NULL,1,NULL,1,1),
	(255,'San Jerónimo',15,NULL,1,NULL,1,1),
	(256,'Purulhá',15,NULL,1,NULL,1,1),
	(257,'Cobán',16,NULL,1,NULL,1,1),
	(258,'Santa Cruz Verapaz',16,NULL,1,NULL,1,1),
	(259,'San Cristóbal Verapaz',16,NULL,1,NULL,1,1),
	(260,'Tactic',16,NULL,1,NULL,1,1),
	(261,'Tamahú',16,NULL,1,NULL,1,1),
	(262,'Tucurú',16,NULL,1,NULL,1,1),
	(263,'Panzós',16,NULL,1,NULL,1,1),
	(264,'Senahú',16,NULL,1,NULL,1,1),
	(265,'San Pedro Carchá',16,NULL,1,NULL,1,1),
	(266,'San Juan Chamelco',16,NULL,1,NULL,1,1),
	(267,'Lanquín',16,NULL,1,NULL,1,1),
	(268,'Cahabón',16,NULL,1,NULL,1,1),
	(269,'Chisec',16,NULL,1,NULL,1,1),
	(270,'Chahal',16,NULL,1,NULL,1,1),
	(271,'Fray Bartolomé de las Casas',16,NULL,1,NULL,1,1),
	(272,'Santa Catalina la Tinta',16,NULL,1,NULL,1,1),
	(273,'Raxruhá',16,NULL,1,NULL,1,1),
	(274,'Flores',17,NULL,1,NULL,1,1),
	(275,'San José',17,NULL,1,NULL,1,1),
	(276,'San Benito',17,NULL,1,NULL,1,1),
	(277,'San Andrés',17,NULL,1,NULL,1,1),
	(278,'La Libertad',17,NULL,1,NULL,1,1),
	(279,'San Francisco',17,NULL,1,NULL,1,1),
	(280,'Santa Ana',17,NULL,1,NULL,1,1),
	(281,'Dolores',17,NULL,1,NULL,1,1),
	(282,'San Luis',17,NULL,1,NULL,1,1),
	(283,'Sayaxché',17,NULL,1,NULL,1,1),
	(284,'Melchor de Mencos',17,NULL,1,NULL,1,1),
	(285,'Poptún',17,NULL,1,NULL,1,1),
	(286,'Las Cruces',17,NULL,1,NULL,1,1),
	(287,'El Chal',17,NULL,1,NULL,1,1),
	(288,'Puerto Barrios',18,NULL,1,NULL,1,1),
	(289,'Livingston',18,NULL,1,NULL,1,1),
	(290,'El Estor',18,NULL,1,NULL,1,1),
	(291,'Morales',18,NULL,1,NULL,1,1),
	(292,'Los Amates',18,NULL,1,NULL,1,1),
	(293,'Zacapa',19,NULL,1,NULL,1,1),
	(294,'Estanzuela',19,NULL,1,NULL,1,1),
	(295,'Río Hondo',19,NULL,1,NULL,1,1),
	(296,'Gualán',19,NULL,1,NULL,1,1),
	(297,'Teculután',19,NULL,1,NULL,1,1),
	(298,'Usumatlán',19,NULL,1,NULL,1,1),
	(299,'Cabañas',19,NULL,1,NULL,1,1),
	(300,'San Diego',19,NULL,1,NULL,1,1),
	(301,'La Unión',19,NULL,1,NULL,1,1),
	(302,'Huité',19,NULL,1,NULL,1,1),
	(303,'San Jorge',19,NULL,1,NULL,1,1),
	(304,'Chiquimula',20,NULL,1,NULL,1,1),
	(305,'San José La Arada',20,NULL,1,NULL,1,1),
	(306,'San Juan Ermita',20,NULL,1,NULL,1,1),
	(307,'Jocotán',20,NULL,1,NULL,1,1),
	(308,'Camotán',20,NULL,1,NULL,1,1),
	(309,'Olopa',20,NULL,1,NULL,1,1),
	(310,'Esquipulas',20,NULL,1,NULL,1,1),
	(311,'Concepción Las Minas',20,NULL,1,NULL,1,1),
	(312,'Quetzaltepeque',20,NULL,1,NULL,1,1),
	(313,'San Jacinto',20,NULL,1,NULL,1,1),
	(314,'Ipala',20,NULL,1,NULL,1,1),
	(315,'Jalapa',21,NULL,1,NULL,1,1),
	(316,'San Pedro Pinula',21,NULL,1,NULL,1,1),
	(317,'San Luis Jilotepeque',21,NULL,1,NULL,1,1),
	(318,'San Manuel Chaparrón',21,NULL,1,NULL,1,1),
	(319,'San Carlos Alzatate',21,NULL,1,NULL,1,1),
	(320,'Monjas',21,NULL,1,NULL,1,1),
	(321,'Mataquescuintla',21,NULL,1,NULL,1,1),
	(322,'Jutiapa',22,NULL,1,NULL,1,1),
	(323,'El Progreso',22,NULL,1,NULL,1,1),
	(324,'Santa Catarina Mita',22,NULL,1,NULL,1,1),
	(325,'Agua Blanca',22,NULL,1,NULL,1,1),
	(326,'Asunción Mita',22,NULL,1,NULL,1,1),
	(327,'Yupiltepeque',22,NULL,1,NULL,1,1),
	(328,'Atescatempa',22,NULL,1,NULL,1,1),
	(329,'Jerez',22,NULL,1,NULL,1,1),
	(330,'El Adelanto',22,NULL,1,NULL,1,1),
	(331,'Zapotitlán',22,NULL,1,NULL,1,1),
	(332,'Comapa',22,NULL,1,NULL,1,1),
	(333,'Jalpatagua',22,NULL,1,NULL,1,1),
	(334,'Conguaco',22,NULL,1,NULL,1,1),
	(335,'Moyuta',22,NULL,1,NULL,1,1),
	(336,'Pasaco',22,NULL,1,NULL,1,1),
	(337,'San José Acatempa',22,NULL,1,NULL,1,1),
	(338,'Quesada',22,NULL,1,NULL,1,1);

/*!40000 ALTER TABLE `municipios` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pacient
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pacient`;

CREATE TABLE `pacient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `day_of_birth` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `DPI` varchar(13) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sick` varchar(500) DEFAULT NULL,
  `medicaments` varchar(500) DEFAULT NULL,
  `alergy` varchar(500) DEFAULT NULL,
  `is_favorite` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `pacient` WRITE;
/*!40000 ALTER TABLE `pacient` DISABLE KEYS */;

INSERT INTO `pacient` (`id`, `no`, `name`, `lastname`, `gender`, `day_of_birth`, `email`, `password`, `address`, `phone`, `DPI`, `image`, `sick`, `medicaments`, `alergy`, `is_favorite`, `is_active`, `created_at`)
VALUES
	(1,NULL,'Test','nuevo','h','0000-00-00','nuevo@co.com',NULL,'nueva calle','56212123',NULL,NULL,'','','',1,1,'2021-09-21 21:10:56');

/*!40000 ALTER TABLE `pacient` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table payment
# ------------------------------------------------------------

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;

INSERT INTO `payment` (`id`, `name`)
VALUES
	(1,'Pendiente'),
	(2,'Pagado'),
	(3,'Anulado');

/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table reservation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `reservation`;

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `note` text,
  `message` text,
  `date_at` varchar(50) DEFAULT NULL,
  `time_at` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `pacient_id` int(11) DEFAULT NULL,
  `symtoms` text,
  `sick` text,
  `medicaments` text,
  `user_id` int(11) DEFAULT NULL,
  `medic_id` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `is_web` tinyint(1) NOT NULL DEFAULT '0',
  `payment_id` int(11) NOT NULL DEFAULT '1',
  `status_id` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `status_id` (`status_id`),
  KEY `user_id` (`user_id`),
  KEY `pacient_id` (`pacient_id`),
  KEY `medic_id` (`medic_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `reservation_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `reservation_ibfk_4` FOREIGN KEY (`pacient_id`) REFERENCES `pacient` (`id`),
  CONSTRAINT `reservation_ibfk_5` FOREIGN KEY (`medic_id`) REFERENCES `medic` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;

INSERT INTO `reservation` (`id`, `title`, `note`, `message`, `date_at`, `time_at`, `created_at`, `pacient_id`, `symtoms`, `sick`, `medicaments`, `user_id`, `medic_id`, `price`, `is_web`, `payment_id`, `status_id`)
VALUES
	(1,'test','',NULL,'2021-09-22','12:05','2021-09-21 21:13:51',1,'','Gine','',1,1,150,0,1,1),
	(2,'2 cita',NULL,NULL,'2021-09-27','13:30','2021-09-21 21:13:51',1,' ','Gine',' ',1,1,1,0,1,1),
	(3,'nueva','nuevo',NULL,'2021-09-14','12:00','2021-09-24 20:58:59',1,'','','',1,1,1,0,1,1),
	(4,'test','',NULL,'2021-10-04','12:00','2021-09-30 17:10:05',1,'','','',1,1,1,0,1,1),
	(5,'Test 1','Test de nota',NULL,'2021-10-22','12:00','2021-10-05 11:09:45',1,'','','',1,2,0,0,1,1);

/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table status
# ------------------------------------------------------------

DROP TABLE IF EXISTS `status`;

CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;

INSERT INTO `status` (`id`, `name`)
VALUES
	(1,'Pendiente'),
	(2,'Aplicada'),
	(3,'No asistio'),
	(4,'Cancelada');

/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `idlocation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;

INSERT INTO `user` (`id`, `username`, `name`, `lastname`, `email`, `password`, `is_active`, `is_admin`, `created_at`, `idlocation`)
VALUES
	(1,'admin',NULL,NULL,NULL,'90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad',1,1,'2021-09-08 17:25:39',NULL),
	(2,'UsusariOP','test','apos',NULL,'63982e54a7aeb0d89910475ba6dbd3ca6dd4e5a1',1,0,'2021-09-27 16:58:38',2);

/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
